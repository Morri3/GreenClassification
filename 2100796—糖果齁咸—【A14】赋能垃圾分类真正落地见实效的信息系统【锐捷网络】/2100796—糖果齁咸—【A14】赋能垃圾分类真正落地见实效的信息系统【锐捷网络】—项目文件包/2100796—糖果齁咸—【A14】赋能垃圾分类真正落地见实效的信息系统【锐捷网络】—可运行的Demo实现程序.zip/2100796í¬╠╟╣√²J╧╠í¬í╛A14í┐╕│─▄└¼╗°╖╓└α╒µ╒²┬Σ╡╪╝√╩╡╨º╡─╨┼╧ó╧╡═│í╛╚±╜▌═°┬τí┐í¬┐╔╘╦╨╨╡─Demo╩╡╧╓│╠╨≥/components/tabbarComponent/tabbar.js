// tabBarComponent/tabBar.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabbar:{
      type: Object,
      value:{
        "backgroundColor": "#fff",
        "color": "#979795",
        "selectedColor": "#ffffff",
        "list": [
          {
            "pagePath": "/pages/index/index",
            "iconPath": "icon/home2.png",
            "selectedIconPath": "icon/home2_selected.png",
            "text": "主页"
          },
          {
            "pagePath": "/pages/camera/camera",
            "iconPath": "icon/camera.png",
            "isSpecial": true,
            "text": "垃圾识别"
          },
          {
            "pagePath": "/pages/my/my",
            "iconPath": "icon/my2.png",
            "selectedIconPath": "icon/my2_selected.png",
            "text": "我的"
          },
        ]
        
      }
    }
    }
      
    
  ,
  data: {
    
  },
  /**
   * 组件的初始数据
   */
  

  /**
   * 组件的方法列表
   */
  methods: {
    
  }
})
