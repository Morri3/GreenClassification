// app.js
App({
  data: {
    userid: 1,
    currentuser: '',
  },

  onLaunch() {
    var that = this;
    wx.cloud.init({
      env: "cloud1-4gtlg0skede663ea"
    })
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    wx.request({
      url: 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=qQdVWdZMkAPsVqBfcNDIorT9&client_secret=d8R27VrXi84RpdhEpgZRgcmsLU8ZvGMk',
      method: 'POST',
      dataType: 'json',
      header: {
        'content-type': 'application/json; charset-UTF-8'
      },
      success(res) {
        that.globalData.accessToken = res.data.access_token
        console.log("获取access_Token成功!")
      },
      fail: function (res) {
        console.log("获取access_Token失败!")
      },
    })
  },

  editTabbar: function () {
    let tabbar = this.globalData.tabBar;
    let currentPages = getCurrentPages();
    let _this = currentPages[currentPages.length - 1];
    let pagePath = _this.route;
    (pagePath.indexOf('/') != 0) && (pagePath = '/' + pagePath);
    for (let i in tabbar.list) {
      tabbar.list[i].selected = false;
      (tabbar.list[i].pagePath == pagePath) && (tabbar.list[i].selected = true);
    }
    _this.setData({
      tabbar: tabbar
    });
  },

  globalData: {
    cityInfo: '',
    userInfo: null,
    wrong: [],
    accessToken: '',
    base64: '',
    filePath: '',

    difficulty1: '普通', //游戏一难度
    difficulty2: '普通', //游戏二难度
    difficulty4: '普通', //游戏四难度

    tabBar: {
      "backgroundColor": "#ffffff",
      "color": "#CCCCCC",
      "selectedColor": "#CC0000",
      "list": [{
          "pagePath": "/pages/index/index",
          "iconPath": "icon/home.png",
          "selectedIconPath": "icon/home_selected.png",
          "text": "首页"
        },
        {
          "pagePath": "/pages/add/add",
          "iconPath": "icon/camera.png",
          "isSpecial": true,
          "text": "垃圾识别"
        },
        {
          "pagePath": "/pages/my/my",
          "iconPath": "icon/my.png",
          "selectedIconPath": "icon/my_selected.png",
          "text": "我的"
        },

      ]
    }
  },



})