// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
    env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
    // console.log(event.collection, event.level, event.size);
    return db.collection(event.collection)
        .aggregate()
        .match({
            level: event.level,
        })
        .sample({
            size: event.size,
        }).end()
    // return db.collection('game3')
    //     .aggregate()
    //     .match({
    //         level: '困难',
    //     })
    //     .sample({
    //         size: 10,
    //     }).end()
}