// pages/fldt/fldt.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
  
    problemnum:0,//当前题目下标
    problemsum:10,//总共题目数
    time:60,
    // chooseValue: [], // 选择的答案序列
    // totalScore: 100, // 总分
    // wrong: 0, // 错误的题目数量
  
    selectedrubbish:'',//当前选中的垃圾桶
    selectindex:0,//当前选中的垃圾桶下标
    rubbish:[{"id":0,"background":"rgba(31, 174, 218, 0.95)","img":"cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/可回收物.png","title":"易腐垃圾","isselected":false},
    {"id":1,"background":"rgba(98, 134, 96, 0.95)","img":"","title":"可回收物","isselected":false},
    {"id":2,"background":"rgba(255, 165, 0, 0.95)","img":"","title":"其他垃圾","isselected":false},
    {"id":3,"background":"rgba(221, 103, 103, 0.95)","img":"","title":"有害垃圾","isselected":false}],//存放四个垃圾桶信息



  },
  //点击垃圾桶的响应事件
  isselect:function(e){
    console.log(e)
    const{selectindex} = e.currentTarget.dataset;//获取当前事件信息
    this.setData({
      selectindex:selectindex
    })
    const {rubbish} = this.data;
    rubbish.forEach((v,i)=>i==selectindex?v.isselected=true:v.isselected=false)
    this.setData({
      rubbish
    })
    console.log(this.data.rubbish)
  
    //更新isselected,更换题目

    
  },
  
  yflj:function(e){
    console.log("选择了易腐垃圾");

    // this.data.chooseValue[this.data.problemnum] = getCurrentPages();
    console.log(this.data.chooseValue[this.data.problemnum]);
  },

  khsw:function(e){
    console.log("选择了可回收物")
  },

  qtlj:function(e){
    console.log("选择了其他垃圾")
  },

  yhlj:function(e){
    console.log("选择了有害垃圾")
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})