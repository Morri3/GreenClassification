var app = getApp();

//var作用范围是全局，let作用范围是块内
var index = 0; //错题数组的遍历下标
var countDown = 60 //60s倒计时
var over=false;//是否答题完成

Page({
  data: {
    second:0,//剩余时间
    useTime: 0, //使用时间
    // timer: '', //计时器
    // currenttime: 0, //当前已用时间
    score: 0, //最终成绩
    selectedrubbish: '', //当前选中的垃圾桶
    selectindex: -1, //当前选中的垃圾桶下标
    rubbish: [{
        "id": 0,
        "background": "rgba(31, 174, 218, 0.95)",
        "img": "cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/厨余垃圾.png",
        "title": "易腐垃圾",
        "isselected": false
      },
      {
        "id": 1,
        "background": "rgba(98, 134, 96, 0.95)",
        "img": "cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/可回收物.png",
        "title": "可回收物",
        "isselected": false
      },
      {
        "id": 2,
        "background": "rgba(255, 165, 0, 0.95)",
        "img": "cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/其他垃圾.png",
        "title": "其他垃圾",
        "isselected": false
      },
      {
        "id": 3,
        "background": "rgba(221, 103, 103, 0.95)",
        "img": "cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/有害垃圾.png",
        "title": "有害垃圾",
        "isselected": false
      }
    ], //存放四个垃圾桶信息
    problemnum: 0, //当前题目下标
    problemsum: 10, //总共题目数
    question:[], //题目
    correctnum: 0, //正确的答题数
    wrongnum: 0, //错误的答题数
    showModal: false, //是否显示弹窗
    wrong: [], //错题
    difficulty2:'',//题目难度
    tmp_ques:[],
  },

  //点击垃圾桶的响应事件   先取然后设置再放回去
  isselect: function (e) {
    console.log(e)
    const {
      selectindex
    } = e.currentTarget.dataset; //获取当前事件信息
    this.setData({
      selectindex: selectindex
    })
    const {
      rubbish
    } = this.data;
    rubbish.forEach((v, i) => i == selectindex ? v.isselected = true : v.isselected = false) //若垃圾桶v被选中就设置isselected为true
    this.setData({
      rubbish //把整个rubbish列表设置完后放回到data中
    })
    console.log(this.data.rubbish)
  },

  //下一题
  nextproblem: function (e) {
    console.log(e)
    const {
      selectindex
    } = e.currentTarget.dataset; //获取当前事件信息
    const {
      rubbish
    } = this.data;
    const {
      question
    } = this.data;
    const {
      wrong
    } = this.data;

    //判断是否选择选项
    if (this.data.selectindex != -1) { //有选择垃圾桶
      console.log("选择了垃圾桶")
    } else if (this.data.selectindex == -1) { //未选择垃圾桶
      wx.showToast({ //弹窗
        title: '请选择答案！',
        icon: 'none',
        duration: 2000,
        success: function () {
          return;
        }
      })
      return;
    }

    //验证答案是否正确
    var flag = false;
    if (this.data.question[this.data.problemnum].answerindex == this.data.selectindex) { //回答正确
      console.log("回答正确")
      this.setData({
        correctnum: this.data.correctnum + 1
      })
      flag = true
    } else { //回答错误
      console.log("回答错误")
      this.setData({
        wrongnum: this.data.wrongnum + 1,
      })
      flag = false
    }
    question.forEach((v, i) => {
      i == this.data.problemnum ? v.selectindex = this.data.selectindex : '';
      if (flag == true) {
        i == this.data.problemnum ? v.iscorrect = 1 : -1;
      } else {
        i == this.data.problemnum ? v.iscorrect = 0 : -1;
      }
    }) //将选择的选项放到option中
    this.setData({
      question
    })
    console.log(this.data.question)

    //将错题放wrong数组里
    if (this.data.question[this.data.problemnum].iscorrect == 0) {
      let choose = this.data.question[this.data.problemnum].selectindex
      let name;
      if (choose == 0) {
        name = "易腐垃圾"
      } else if (choose == 1) {
        name = "可回收物"
      } else if (choose == 2) {
        name = "其他垃圾"
      } else if (choose == 3) {
        name = "有害垃圾"
      }
      let obj = {
        id: index,
        ques: this.data.question[this.data.problemnum].img,
        choose: name,
        ans: this.data.question[this.data.problemnum].answername,
      } //对象
      this.data.wrong.push(obj)
      index = index + 1
    }
    this.setData({
      wrong
    })
    console.log(this.data.wrong)

    //更换题目
    this.setData({
      problemnum: this.data.problemnum + 1 //当前题目下标+1
    })
    console.log("this.data.problemnum" + this.data.problemnum)

    //更新selectindex和isselected
    this.setData({
      selectindex: -1
    })
    console.log("this.data.selectindex" + this.data.selectindex)
    rubbish.forEach(v => v.isselected = false) //把所有isselected恢复false
    this.setData({
      rubbish //把整个rubbish列表设置完后放回到data中
    })
    console.log(this.data.rubbish)
    console.log(this.data.correctnum)
    console.log(this.data.wrongnum)
  },

  //提交答卷函数
  sub: function (e) {
    if(over==false){

    }
    over=true//答题完成

    console.log(e)
    const {
      selectindex
    } = e.currentTarget.dataset; //获取当前事件信息
    const {
      rubbish
    } = this.data;
    const {
      question
    } = this.data;
    const {
      wrong
    } = this.data;

    //判断是否选择选项
    if (this.data.selectindex != -1) { //有选择垃圾桶
      console.log("选择了垃圾桶")
    } else if (this.data.selectindex == -1) { //未选择垃圾桶
      wx.showToast({ //弹窗
        title: '请选择答案！',
        icon: 'none',
        duration: 2000,
        success: function () {
          return;
        }
      })
      return;
    }

    //验证答案是否正确
    var flag = false;
    if (this.data.question[this.data.problemnum].answerindex == this.data.selectindex) { //回答正确
      console.log("回答正确")
      this.setData({
        correctnum: this.data.correctnum + 1
      })
      flag = true
    } else { //回答错误
      console.log("回答错误")
      this.setData({
        wrongnum: this.data.wrongnum + 1
      })
      flag = false
    }
    question.forEach((v, i) => {
      i == this.data.problemnum ? v.selectindex = this.data.selectindex : '';
      if (flag == true) {
        i == this.data.problemnum ? v.iscorrect = 1 : -1;
      } else {
        i == this.data.problemnum ? v.iscorrect = 0 : -1;
      }
    }) //将选择的选项放到option中
    this.setData({
      question
    })
    console.log(this.data.question)

    //将错题放wrong数组里
    if (this.data.question[this.data.problemnum].iscorrect == 0) {
      let choose = this.data.question[this.data.problemnum].selectindex
      let name;
      if (choose == 0) {
        name = "易腐垃圾"
      } else if (choose == 1) {
        name = "可回收物"
      } else if (choose == 2) {
        name = "其他垃圾"
      } else if (choose == 3) {
        name = "有害垃圾"
      }
      let obj = {
        id: index,
        ques: this.data.question[this.data.problemnum].img,
        choose: name,
        ans: this.data.question[this.data.problemnum].answername,
      } //对象
      this.data.wrong.push(obj)
      index = index + 1
    }
    this.setData({
      wrong
    })
    console.log(this.data.wrong)

    //更新selectindex和isselected
    this.setData({
      selectindex: -1
    })
    console.log("this.data.selectindex" + this.data.selectindex)
    rubbish.forEach(v => v.isselected = false) //把所有isselected恢复false
    this.setData({
      rubbish //把整个rubbish列表设置完后放回到data中
    })
    console.log(this.data.rubbish)
    console.log(this.data.correctnum)
    console.log(this.data.wrongnum)

    //计算最终得分
    var perscore = 100 / this.data.problemsum
    this.setData({
      score: this.data.correctnum * perscore,
      useTime:countDown- this.data.second
    })
    console.log(this.data.score)

    //更新用户表中的第二个游戏的成绩数据
    wx.cloud.init()//初始化
    const db = wx.cloud.database()//获取db数据库
    var app = getApp()
    
    // db.collection('user').where({//如果没有查询约束条件就没有where
    //   // id:app.globalData.userid
    //   id:app.data.userid
    // }).update({//更新
    //   data:{
    //     score2:this.data.score,
    //     time2:this.data.useTime
    //   }
    // })

    db.collection('user').where({//如果没有查询约束条件就没有where
      id:app.data.userid
    }).get()
      .then(res=>{
        if(this.data.difficulty2=='普通'){//普通难度 更新数据
          if(this.data.score>res.data[0].score2e || 
            (this.data.score==res.data[0].score2e && this.data.useTime<res.data[0].time2e)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
            db.collection('user').where({//如果没有查询约束条件就没有where
              id:app.data.userid
            }).update({//更新
              data:{
                score2e:this.data.score,
                time2e:this.data.useTime
              }
            })
          }
        }else if(this.data.difficulty2=='困难'){//困难难度 更新数据
          if(this.data.score>res.data[0].score2d || 
            (this.data.score==res.data[0].score2d && this.data.useTime<res.data[0].time2d)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
              db.collection('user').where({//如果没有查询约束条件就没有where
              id:app.data.userid
            }).update({//更新
              data:{
                score2d:this.data.score,
                time2d:this.data.useTime
              }
            })
          }
        } 
    }) 

    // //停止计时
    // clearInterval(this.data.timer);

    //跳出弹窗显示答题情况
    this.setData({
      showModal: true
    })
  },

  //空函数
  preventTouchMove: function () {},

  //关闭弹窗
  closemodal: function () {
    this.setData({
      showModal: false
    })
    wx.redirectTo({
      url: '../game2/game2',
    })
  },

  //查看错题
  searchwrong: function (e) {
    app.globalData.wrong = this.data.wrong
    wx.redirectTo({
      url: '../wrongquestion2/wrongquestion2',
    })
  },

  //关闭弹窗
  searchclose: function (e) {
    // wx.redirectTo({
    //   url: '../game2/game2',
    // })
    wx.navigateBack({
      delta: 1,
    })
  },

  //倒计时函数
  countDown(that) {
    if(over==true){//如果答题完成则停止倒计时
      return
    }
    const {
      rubbish
    } = this.data;
    if (that.data.second == 0) {//倒计时结束了
      over=true//倒计时结束停止倒计时
      this.data.useTime = countDown - this.data.second
      this.data.rubbish.forEach(v => v.isselected = false) //把所有isselected恢复false
      this.setData({
        useTime: this.data.useTime,
        showModal: true,
        correctnum: this.data.correctnum,
        wrongnum: this.data.wrongnum,
        problemsum: this.data.problemsum,
        score: parseInt(100 * this.data.correctnum / this.data.problemsum),
        selectindex: -1,
        rubbish
      })
      //更新用户表中的第二个游戏的成绩数据
      wx.cloud.init()//初始化
      const db = wx.cloud.database()//获取db数据库
      db.collection('user').where({//如果没有查询约束条件就没有where
        id:app.data.userid
      }).get()
        .then(res=>{
          if(this.data.difficulty2=='普通'){//普通难度 更新数据
            if(this.data.score>res.data[0].score2e || 
              (this.data.score==res.data[0].score2e && this.data.useTime<res.data[0].time2e)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
              db.collection('user').where({//如果没有查询约束条件就没有where
                id:app.data.userid
              }).update({//更新
                data:{
                  score2e:this.data.score,
                  time2e:this.data.useTime
                }
              })
            }
          }else if(this.data.difficulty2=='困难'){//困难难度 更新数据
            if(this.data.score>res.data[0].score2d || 
              (this.data.score==res.data[0].score2d && this.data.useTime<res.data[0].time2d)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
                db.collection('user').where({//如果没有查询约束条件就没有where
                id:app.data.userid
              }).update({//更新
                data:{
                  score2d:this.data.score,
                  time2d:this.data.useTime
                }
              })
            }
          } 
      })    
      console.log(60-this.data.second)
      return
    }
  
    that.setData({
      second: that.data.second - 1,
    })
    setTimeout(function () {
      that.countDown(that)
    }, 1000)
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    over=false//初始化时开始计时
    //获取游戏难度
    this.setData({
      difficulty2:app.globalData.difficulty2
    })
    console.log(this.data.difficulty2)
    // //生成随机数组
    // var arr=new Array();
    // for(var i=0;i<10;i++){
    //   if(this.data.difficulty=="普通"){
    //     arr[i]=parseInt(Math.random()*10);
    //   }else if(this.data.difficulty=="困难"){
    //     arr[i]=parseInt(Math.random()*10+10);
    //   }else if(this.data.difficulty=="特别难"){
    //     arr[i]=parseInt(Math.random()*10+20);
    //   }
      
    //   for(var j=0;j<i;j++){
    //     if(arr[i]==arr[j]){
    //       i=i-1;
    //       break;
    //     }
    //   }
    // }
    // console.log(arr)
    //从数据库查询记录
    wx.cloud.init();
    const db = wx.cloud.database();
    const _ =db.command;

    db.collection('game2').where({
      level:this.data.difficulty2,
      // id:_.in(arr) //根据随机数数组查找
    }).get({
      success:res=>{
        //对结果进行随机排序
        res.data.sort(function(){
          return Math.random() - 0.5;
        })
        console.log(res.data)
        //设置变量的值
        this.setData({
          problemsum: 10,
          problemnum: 0,
          question:res.data,
        })
        console.log(this.data.question)
      }
    })
    
    //加载题目(使用云函数【旧】)
    // this.getProblem();

    //倒计时
    this.setData({
      second: countDown,
    })
    this.countDown(this)
    // //开始计时（正计时【旧】）
    // const that = this;
    // var time = that.data.currenttime
    // that.data.timer = setInterval(function () {
    //   time++
    //   that.setData({
    //     currenttime: time
    //   })
    // }, 950)
  },

  //获取云函数
  getProblem() {
    wx.cloud.callFunction({
      name: "getProblem",
      data: {
        size: this.data.problemsum,
        collection: "game2"
      }
    }).then(res => { //设置数据库中获取的数据
      this.setData({
        problemsum: res.result.list.length,
        problemnum: 0,
        question: res.result.list,
      })
      console.log(this.data.question);
    }).catch(res => {
      console.log("no_onLoad", res);
    })
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})