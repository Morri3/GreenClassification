// pages/modify/modify.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    username:null,
    usersex:null,
    usercity:null,
    userage:null,
    userid:'',
    user:''
  },

  //昵称输入
  NameInput:function(e){
    this.setData({
      username:e.detail.value,
    })
  },

  //性别输入
  SexInput:function(e){
    this.setData({
      usersex:e.detail.value,
    })
  },

  //城市输入
  CityInput:function(e){
    this.setData({
      usercity:e.detail.value,
    })
  },

  //年龄输入
  AgeInput:function(e){
    this.setData({
      userage:e.detail.value,
    })
  },

  btn_sure:function(e){
    //更新昵称
    if(this.data.username!=null){//如果不为null说明有输入，更新数据
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
      id:this.data.userid,
      }).update({
      data:({
        name:this.data.username
      })
      },500) 
      db.collection('comment').where({
        userid: this.data.userid,
      }).update({
        data: ({
          username: this.data.username
        })
      })


    }


    //更新性别
    if(this.data.usersex!=null){//如果不为null说明有输入，更新数据
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
      id:this.data.userid,
      }).update({
      data:({
        sex:this.data.usersex
      })
      },500) 
    }
    //更新城市
    if(this.data.usercity!=null){
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
      id:this.data.userid,
      }).update({
      data:({
        city:this.data.usercity
      })
      },500) 
    }
    //更新年龄
    if(this.data.userage!=null){
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
      id:this.data.userid,
      }).update({
      data:({
        age:this.data.userage
      })
      }) 
    }

    //跳转到my页面
    wx.switchTab({
      url: '../my/my'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.setData({
      userid:app.data.userid
    })

    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
    id:this.data.userid,
    }).get({
    success:res=>{
    this.setData({
      user:res.data[0]
    })
    }
    }) 

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})