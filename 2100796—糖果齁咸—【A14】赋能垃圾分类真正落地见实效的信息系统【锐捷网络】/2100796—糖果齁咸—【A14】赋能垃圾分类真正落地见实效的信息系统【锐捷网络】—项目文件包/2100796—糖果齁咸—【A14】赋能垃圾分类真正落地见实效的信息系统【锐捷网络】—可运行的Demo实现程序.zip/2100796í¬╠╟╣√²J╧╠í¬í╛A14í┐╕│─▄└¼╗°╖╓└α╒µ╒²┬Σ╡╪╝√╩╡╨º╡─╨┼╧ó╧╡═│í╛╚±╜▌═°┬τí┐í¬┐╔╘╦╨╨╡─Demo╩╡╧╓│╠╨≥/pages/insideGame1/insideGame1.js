var to = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
]
var ani_to = [
  [0, -1],
  [0, 1],
  [-1, 0],
  [1, 0],
]
var length = 5 //棋盘大小
var rubbish = []
// 小人图像
var people = "cloud://cloud1-4gtlg0skede663ea.636c-cloud1-4gtlg0skede663ea-1306827322/zyy/game1/小人.png"
var over = false
var click = true //当前状态是否可以点击
var interval //计时器
var rpx //像素比
var chessboard

Page({
  data: {
    chessboardDatas: [], //棋盘，{img,kind,color,ani}
    num: 0, //要选的垃圾数量
    x: 0, //初始点 && 当前位置
    y: 0,
    kind_id: 0, //垃圾类型
    kind: 0, //垃圾类型名字
    yes: 0, //正确数量
    useTime: 0, //耗时
    score: 0, //得分
    best: 0, //最好得分
    showModal: false, //显示成绩

    dh: [
      ['', '上', ''],
      ['左', '', '右'],
      ['', '下', '']
    ],
  },

  ani_right(xx, yy, x, y) {
    let animation = wx.createAnimation()
    animation.translate(x * 65 * rpx, y * 65 * rpx).step({
      duration: 300,
    })
    this.setData({
      [`chessboardDatas[${xx}][${yy}].ani`]: animation.export()
    })
  },

  ani_wrong(xx, yy, x, y) {
    let animation = wx.createAnimation()
    animation.translate(x * 20 * rpx, y * 20 * rpx).step({
      duration: 200,
    })
    animation.translate(0, 0).step({
      duration: 100,
    })
    this.setData({
      [`chessboardDatas[${xx}][${yy}].ani`]: animation.export()
    })
  },

  ani_throw(x, y) {
    let animation = wx.createAnimation()
    animation.translate((2 - y) * 65 * rpx, 800).rotate(180).step({
      duration: 300,
    })
    this.setData({
      [`chessboardDatas[${x}][${y}].ani`]: animation.export()
    })
  },

  lock() {
    click = false
  },
  unlock() {
    click = true
  },

  move(e) {
    if (!click) return
    this.lock()

    let direction = e.currentTarget.dataset.direction
    let x = this.data.x
    let y = this.data.y
    let xx = x + to[direction][0]
    let yy = y + to[direction][1]
    if ((0 <= xx && xx < length && 0 <= yy && yy < length)) {
      if (this.data.kind == this.data.chessboardDatas[xx][yy].kind) {
        this.data.yes++
        this.ani_right(x, y, ani_to[direction][0], ani_to[direction][1])
        let that = this
        setTimeout(function () {
          that.ani_throw(xx, yy)
          setTimeout(function () {
            that.setData({
              [`chessboardDatas[${xx}][${yy}]`]: {
                img: people,
                color: "border: solid red 5rpx",
                ani: wx.createAnimation().translate(0, 0).step({
                  duration: 0
                }).export(),
              },
              x: xx,
              y: yy,
              [`chessboardDatas[${x}][${y}]`]: {
                img: "",
                color: "",
                ani: wx.createAnimation().translate(0, 0).step({
                  duration: 0
                }).export(),
              },
            })
            setTimeout(() => {
              that.unlock()
            }, 100);
          }, 200)
        }, 100)
      } else if (this.data.chessboardDatas[xx][yy].img != "") {
        this.ani_wrong(x, y, ani_to[direction][0], ani_to[direction][1])
        this.unlock()
      } else {
        this.ani_right(x, y, ani_to[direction][0], ani_to[direction][1])
        let that = this
        setTimeout(function () {
          that.setData({
            [`chessboardDatas[${x}][${y}]`]: {
              img: "",
              color: "",
              ani: wx.createAnimation().translate(0, 0).step({
                duration: 1
              }).export(),
            },
            [`chessboardDatas[${xx}][${yy}]`]: {
              img: people,
              color: "border: solid red 5rpx",
              ani: wx.createAnimation().translate(0, 0).step({
                duration: 1
              }).export(),
            },
            x: xx,
            y: yy,
          })
          that.unlock()
        }, 300)
      }
    } else {
      this.ani_wrong(x, y, ani_to[direction][0], ani_to[direction][1])
      this.unlock()
    }

    if (this.data.yes == this.data.num && this.data.num != 0) {
      let that = this
      setTimeout(function () {
        that.over()
      }, 1000)
    }
  },

  over() {
    click = false
    over = true
    this.setData({
      showModal: true,
      yes: this.data.yes,
      score: parseFloat((this.data.useTime / this.data.yes).toFixed(2))
    })
    clearInterval(interval)
    let data = {}
    if (length==4) {
      data = {
        score1e: this.data.score,
        time1e: this.data.useTime,
      }
    } else {
      data = {
        score1d: this.data.score,
        time1d: this.data.useTime,
      }
    }
    if (this.data.best == 0 || this.data.score < this.data.best) {
      this.setData({
        best: this.data.score,
      })
      let openid = getApp().data.userid
      wx.cloud.database().collection("user")
        .where({
          _openid: openid,
        })
        .update({
          data: data
        })
    }
  },

  //关闭弹窗
  searchclose: function (e) {
    wx.navigateBack({
      delta: 1,
    })
  },

  time() {
    let that = this
    clearInterval(interval)
    interval = setInterval(function () {
      that.setData({
        useTime: that.data.useTime + 1,
      })
    }, 1000)
  },

  // calc(x, y) {
  //   let res = 0
  //   for (let i = 0; i < 4; i++) {
  //     let xx = x + to[i][0]
  //     let yy = y + to[i][1]
  //     if (0 <= xx && xx < length && 0 <= yy && yy < length && chessboard[xx][yy] != "") res++
  //   }
  //   return res
  // },
  chk(xx, yy, x, y) {
    let xxx, yyy
    for (let i = 0; i < 4; i++) {
      xxx = xx + to[i][0]
      yyy = yy + to[i][1]
      if (xxx == x && yyy == y) continue
      if (0 <= xxx && xxx < length && 0 <= yyy && yyy < length && chessboard[xxx][yyy] != "") {
        return false
      }
    }
    return true
  },

  reset() {
    click = true
    over = false
    chessboard = this.data.chessboardDatas
    for (let i = 0; i < chessboard.length; i++) {
      for (let j = 0; j < chessboard[i].length; j++) {
        chessboard[i][j] = ""
      }
    }
    for (let i = 0; i < 4; i++) {
      rubbish[i].sort(function () {
        return 0.5 - Math.random()
      })
    }

    let num = length + Math.floor(Math.random() * (length-2)) + 2
    let x = Math.floor(Math.random() * length)
    let y = Math.floor(Math.random() * length)
    let xxx = x
    let yyy = y
    let kind_id = Math.floor(Math.random() * 4)
    let kind = rubbish[kind_id][0].kind
    let arr = [{
      x: x,
      y: y
    }]

    // chessboard[x][y] = {
    //   img: people,
    //   kind: this.data.kind,
    //   color: "border: solid red 5rpx",
    // }

    let pos = [0, 0, 0, 0] //top
    chessboard[x][y] = {
      img: rubbish[kind_id][pos[kind_id]].img,
      kind: rubbish[kind_id][pos[kind_id]].kind,
      color: "",
    }
    pos[kind_id]++
    let fx = [0, 1, 2, 3]
    let flag = 0
    let cnt = 0
    console.log("num", num);
    while (arr.length <= num) { //因为小人占一个num，所以会先多一个此类垃圾
      cnt++
      if (cnt == 20) {
        this.reset()
        return
      }
      fx.sort(function () {
        return 0.5 - Math.random()
      })
      let item = flag ? {
        x: x,
        y: y
      } : {
        x: xxx,
        y: yyy
      }
      let flag2 = false
      for (let i = 0; i < 4; i++) {
        let xx = item.x + to[fx[i]][0]
        let yy = item.y + to[fx[i]][1]
        if (0 <= xx && xx < length && 0 <= yy && yy < length && chessboard[xx][yy] == "") {
          if (this.chk(xx, yy, item.x, item.y)) {
            chessboard[xx][yy] = {
              img: rubbish[kind_id][pos[kind_id]].img,
              kind: rubbish[kind_id][pos[kind_id]].kind,
              color: "",
            }
            pos[kind_id]++
            arr.push({
              x: xx,
              y: yy,
            })
            if (x == item.x && y == item.y) {
              x = xx
              y = yy
            } else {
              xxx = xx
              yyy = yy
            }
            flag2 = true
            break
          }
        }
        if (!flag2) flag = 1 - flag
      }
      // let xx = -1
      // let yy = -1
      // for (let i = 0; i < 4; i++) {
      //   let xxx = item.x + to[i][0]
      //   let yyy = item.y + to[i][1]
      //   if (0 <= xxx && xxx < length && 0 <= yyy && yyy < length && chessboard[xxx][yyy] == "") {
      //     if (xx == -1 || this.calc(xxx, yyy) < this.calc(xx, yy)) {
      //       xx = xxx
      //       yy = yyy
      //     }
      //   }
      // }
      // if (xx != -1) {
      //   chessboard[xx][yy] = {
      //     img: rubbish[kind_id][pos[kind_id]].img,
      //     kind: rubbish[kind_id][pos[kind_id]].kind,
      //     color: "",
      //   }
      //   pos[kind_id]++
      //   arr.push({
      //     x: xx,
      //     y: yy,
      //   })
      // }
    }

    for (let i = 0; i < chessboard.length; i++) {
      for (let j = 0; j < chessboard[i].length; j++) {
        if (chessboard[i][j] == '') {
          let kind2 = (i + j) % 4
          while (kind2 == kind_id || pos[kind2] == rubbish[kind2].length) kind2 = (kind2 + 1) % 4
          chessboard[i][j] = {
            img: rubbish[kind2][pos[kind2]].img,
            kind: rubbish[kind2][pos[kind2]].kind,
            color: "",
          }
          pos[kind2]++
        }
      }
    }
    chessboard[x][y] = {
      img: people,
      kind: this.data.kind,
      color: "border: solid red 5rpx",
    }

    this.setData({
      chessboardDatas: chessboard,
      num: num,
      x: x,
      y: y,
      kind: kind,
      yes: 0,
      useTime: 0,
      showModal: false,
    })
    this.time()
  },

  init() {
    let chessboard = new Array(length);
    for (let i = 0; i < length; i++) {
      chessboard[i] = new Array(length);
    }
    this.setData({
      chessboardDatas: chessboard,
    })

    wx.cloud.database().collection("user")
      .where({
        _openid: getApp().data.userid,
      })
      .get()
      .then(res => {
        let value = length==4 ? res.data[0].score1e : res.data[0].score1d
        if (typeof value === 'number' && !isNaN(value)) {

        } else {
          value = 0
        }
        this.setData({
          best: value
        })
      })
      .catch(res => {
        console.log(res);
      })

    wx.cloud.callFunction({
        name: "getRubbish",
      })
      .then(res => {
        rubbish[0] = res.result.res0.data
        rubbish[1] = res.result.res1.data
        rubbish[2] = res.result.res2.data
        rubbish[3] = res.result.res3.data
        console.log(rubbish);
        this.reset()
      })
      .catch(res => console.log("no_init", res))
  },

  get_rpx() {
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        rpx = 2 * res.windowWidth / 750
      }
    })
  },

  onLoad(e) {
    length = parseInt(e.mode)
    this.get_rpx()
    this.init()
  }
})