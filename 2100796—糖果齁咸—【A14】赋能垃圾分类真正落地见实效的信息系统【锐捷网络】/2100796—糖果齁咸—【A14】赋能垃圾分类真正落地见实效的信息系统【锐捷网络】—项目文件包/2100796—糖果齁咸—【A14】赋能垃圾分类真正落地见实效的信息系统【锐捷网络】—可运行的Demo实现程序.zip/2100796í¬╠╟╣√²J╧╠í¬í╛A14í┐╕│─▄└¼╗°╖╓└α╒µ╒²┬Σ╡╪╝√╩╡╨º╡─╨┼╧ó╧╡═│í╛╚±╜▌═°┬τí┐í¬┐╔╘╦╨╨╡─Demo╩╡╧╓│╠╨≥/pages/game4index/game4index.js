const app = getApp();
var startX, endX;
var moveFlag=true;// 判断执行滑动事件
var show=false;

Page({
  /*页面的初始数据*/
  data: {
    userid:'',
    gameid:4,
    user:'',

    // level:"简单",
    showModal: false, //是否显示游戏规则弹窗
    rules:'在规定的60秒时间内，根据下方待合成回收品提示，找出所有可以合成此回收品的废物，进行垃圾的回收再生！',
    showModal_diff: false, //是否显示游戏难度弹窗
    difficulty4:'',//难度值
  },

  /*开始游戏按钮*/
  btn_startgame:function(e){
    console.log("点击了开始答题");
    if(this.data.difficulty4=="普通"){
      wx.navigateTo({
        url: '../easygame4/easygame4'
      })
    }else if(this.data.difficulty4=="困难"){
      wx.navigateTo({
        url: '../difficultgame4/difficultgame4'
      })
    }
  },

  touchStart:function(e){
    console.log("点击了查看游戏规则");
    startX = e.touches[0].pageX; // 获取触摸时的原点
    moveFlag = true;
  },

  touchMove:function(e){
    endX = e.touches[0].pageX; // 获取触摸时的原点
    if(moveFlag) {
      if(endX - startX > 70) {
        console.log("向右滑动");
        this.rightclose();
        moveFlag = false;
      }
      if(startX - endX > 70) {
        console.log("向左滑动");
        this.leftshow();
        moveFlag = false;
        show=true;
      }
    }
  },

  touchEnd:function(e){
    moveFlag = true; //恢复滑动事件
  },

  /*左划*/
  leftshow:function(){
    //跳出弹窗显示答题情况
    this.setData({
      showModal: true
    })
  },

  /*右划*/
  rightclose:function(){
    //隐藏弹窗
    this.setData({
      showModal:false
    })
  },

  //点击蒙版空白处实现关闭弹窗
  closemask:function(e){
    console.log("关闭了游戏规则");
    //隐藏弹窗
    this.setData({
      showModal:false
    })
  },

  //点击实现显示游戏规则
  showrules:function(e){
    //跳出弹窗显示答题情况
    this.setData({
      showModal: true
    })
  },

  /*难度*/
  difficulty:function(e){
    console.log("点击了难度");
    //跳出弹窗显示难度
    this.setData({
      showModal_diff: true
    })
  },

  //关闭难度弹窗
  closemask_diff:function(e){
    console.log("关闭了游戏难度弹窗");
    //隐藏弹窗
    this.setData({
      showModal_diff:false
    })
  },

  //难度选择
  diff:function(e){
    console.log(e)
    //记录选择的难度
    this.setData({
      difficulty4:e.currentTarget.dataset.diff
    })
    console.log(this.data.difficulty4)
    app.globalData.difficulty4=e.currentTarget.dataset.diff
    console.log(app.globalData.difficulty4)
    //选择难度后关闭弹窗
    this.setData({
      showModal_diff:false
    })
  },

  ranking:function(e){
    console.log("点击了排名");
    wx.navigateTo({
      url: '../ranking4/ranking4',
    })
  },

  forum:function(e){
    console.log("点击了论坛");
    wx.navigateTo({
      url: '../fornum/fornum?gameid='+JSON.stringify(this.data.gameid),
    })
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    var app = getApp()
    this.setData({
      userid:app.data.userid,
      difficulty4:app.globalData.difficulty4
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      id:this.data.userid,
    }).get({
      success:res=>{
        this.setData({
          user:res.data[0]
        }) 
        console.log(this.data.user)
      }
    })
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})