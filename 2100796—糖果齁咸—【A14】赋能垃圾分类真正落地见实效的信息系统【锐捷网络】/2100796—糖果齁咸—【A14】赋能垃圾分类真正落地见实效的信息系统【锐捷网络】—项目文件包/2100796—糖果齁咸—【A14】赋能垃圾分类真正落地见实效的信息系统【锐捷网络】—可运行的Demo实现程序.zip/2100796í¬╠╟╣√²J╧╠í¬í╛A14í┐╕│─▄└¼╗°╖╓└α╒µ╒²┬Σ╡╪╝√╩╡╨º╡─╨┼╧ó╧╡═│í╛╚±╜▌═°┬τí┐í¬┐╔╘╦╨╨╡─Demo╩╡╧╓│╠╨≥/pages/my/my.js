// pages/my/my.js
const app = getApp()

Page({
  /*页面的初始数据*/
  data: {
    userid: '',
    user: '',
    tabbar: {}, //tabbar
    score:'',
  },

  set: function (e) {
    console.log("点击了设置图标")
  },

  // //更换头像
  // changehead: function () {
  //   var _this = this;
  //   wx.chooseImage({
  //     count: 1, // 默认9      
  //     sizeType: ['original', 'compressed'],
  //     // 指定是原图还是压缩图，默认两个都有      
  //     sourceType: ['album', 'camera'],
  //     // 指定来源是相册还是相机，默认两个都有    
  //     success: function (res) {
  //       // 返回选定照片的本地文件路径tempFilePath可以作为img标签的src属性显示图片        
  //       // _this.setData({
  //       //   head: res.tempFilePaths
  //       // })
  //       wx.cloud.init();
  //       const db = wx.cloud.database();
  //       db.collection('user').where({
  //         id: _this.data.userid,
  //       }).update({
  //         data: ({
  //           head: res.tempFilePaths
  //         })
  //       })
  //       console.log("新头像", res.tempFilePaths)
  //       console.log( _this.data.userid)
  //       db.collection('user').where({
  //         id: _this.data.userid,
  //       }).get({
  //         success: res => {
  //           _this.setData({
  //             user: res.data[0]
  //           })
  //           console.log(_this.data.user)

           
  //         }
  //       })
  //       db.collection('comment').where({
  //         userid: _this.data.userid,
  //       }).update({
  //         data: ({
  //           userimg: res.tempFilePaths
  //         })
  //       })

       
  //     }
  //   })
  // },

  modifyinfo: function (e) {
    console.log("点击了修改资料")
    // wx.navigateTo({
    //     url: "/pages/modify/modify?userid="+JSON.stringify(userid),
    // })
  },

  scorecause:function(){
    wx.navigateTo({
        url: "/pages/score/score"
    })
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function () {
    var app = getApp()
    this.setData({
      userid: app.data.userid,
    })
    app.editTabbar();
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      id: this.data.userid,
    }).get({
      success: res => {
        this.setData({
          user: res.data[0]
        })
        console.log(this.data.user)
        console.log(this.data.score)
        
        var game1=0//游戏一分数
        var game4=0//游戏四分数
        if(this.data.user.score1e>0||this.data.user.score1d>0){
          game1 = (10-(this.data.user.score1d+this.data.user.score1e)/2)*0.2
        }
        if(this.data.user.time4d>0||this.data.user.time4e>0){
          game4 = (60-(this.data.user.time4d+this.data.user.time4e)/2)*0.033
        }
        //游戏二三分数
        var game2 = (this.data.user.score2d+this.data.user.score2e)*0.01 //多加了个/2，本来应该有0.02
        var game3 = (this.data.user.score3d+this.data.user.score3e)*0.01
        //评论、看新闻的分数
        var comment = 0.1*this.data.user.commentTime
        var checknews = 0.1*this.data.user.checknewsTime
        
        console.log(game1)
        console.log(game2)
        console.log(game3)
        console.log(game4)
        console.log(comment)
        console.log(checknews)
      
        var score = game1+game2+game3+game4+comment+checknews
        score = score.toFixed(1)
        this.setData({
          score:score
        })
        console.log(this.data.score)
      }
    })
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      id: this.data.userid,
    }).get({
      success: res => {
        this.setData({
          user: res.data[0]
        })
        console.log(this.data.user)
      }
    })
    //加载两遍刷新当前页面(尚且不知道为什么要两遍，一遍有时候会刷新不出来)
    this.onLoad();
    this.onLoad();
  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})