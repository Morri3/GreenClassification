Page({
  /*页面的初始数据*/
  data: {
    userid:'',
    user:'',
    becommented:'',
    newcomment:'',
    lastid:'',
    commentTime:0,
  },

  inputcom(e){
    console.log(e)
    this.setData({
      newcomment:e.detail.value
    })
    
  },

// loadprecommentid:function(){
//   wx.cloud.init();
//   const db = wx.cloud.database();
//   db.collection('comment').get({
//     success:res=>{
//       var maxid = 0;
//       console.log(res.data)

//       // 一次最多返回20个，只能找到这二十个里面最大的那个id,晕死
//       res.data.forEach((v,i) => {
//         if(v.id>=maxid){
//           maxid = v.id
//         }
//       });
//       console.log(maxid)
//       this.setData({
//        lastid:maxid
//     })
//     console.log(this.data.lastid)
//      }
    

//   })
// },

  submit :function(e){
    console.log(this.data.newcomment)
    wx.cloud.init();
    const db = wx.cloud.database();
    
    db.collection('user').where({
      id:this.data.userid
    }).get({
      success:res=>{
        console.log(this.data.commentTime)
        this.setData({
          commentTime:res.data[0].commentTime
        })
        console.log(this.data.commentTime)

        db.collection('user').where({
          id:this.data.userid
        }).update({
          data: ({
            commentTime: this.data.commentTime+1
          })
        })
      }

    })
    
    


    db.collection('comment').add({
      data:{
        id2 :this.data.becommented._id,
        username : this.data.user.name,
        userimg :this.data.user.head,
        userid:this.data.user.id,
        comment:this.data.newcomment,
        // id:this.data.lastid+1,
        gameid :this.data.becommented.gameid,
        issecletd :false,
      }
    })

    wx.showToast({
      title: '添加成功',
    })
    let pages = getCurrentPages();
    let prepage = pages[pages.length-2];
    prepage.loadallcomments();

    wx.navigateBack({
      delta: 0,
    })
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    this.setData({
      commentid:JSON.parse(options.commentid)
    })

    var app = getApp()
    this.setData({
      userid:app.data.userid
    })
    console.log(this.data.userid)
    wx.cloud.init();
    const db = wx.cloud.database();

    // this.loadprecommentid();

    db.collection('comment').where({
      _id:this.data.commentid
    }).get({
      success:res=>{
        this.setData({
          becommented:res.data[0]
        })
        console.log(this.data.becommented)
      }
    })
   
    db.collection('user').where({
      id:this.data.userid
    }).get({
      success:res=>{
        console.log(res.data)
        this.setData({
          user:res.data[0]
        })
        console.log(this.data.user)
      }
    })
  },

})

