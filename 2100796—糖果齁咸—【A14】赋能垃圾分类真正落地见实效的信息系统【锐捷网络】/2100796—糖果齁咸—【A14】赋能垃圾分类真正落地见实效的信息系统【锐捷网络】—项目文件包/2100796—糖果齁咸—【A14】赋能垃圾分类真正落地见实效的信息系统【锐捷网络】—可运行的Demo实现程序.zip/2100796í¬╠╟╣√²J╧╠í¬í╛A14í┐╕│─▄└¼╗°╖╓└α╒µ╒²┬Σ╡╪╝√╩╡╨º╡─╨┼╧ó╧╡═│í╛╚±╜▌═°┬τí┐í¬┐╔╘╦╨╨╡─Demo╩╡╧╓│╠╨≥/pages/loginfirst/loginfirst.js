const app = getApp();
var WxSearch = require('../../wxSearch/wxSearch.js')

Page({
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    currentuser: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    isHide: false,
    isExist: false, //判断该授权用户是否存在用户表中
    head: 0,
    city: '',
    sex: '',
    name: '小糖',
    openid: 'abc',
  },

  async getopenid() {
    wx.cloud.callFunction({
        name: "UserInfo",
      })
      .then(res => {
        console.log(res)
        this.setData({
          openid: res.result.OPENID,
        });
      })
      .catch(res => {
        console.log(res);
      })
  },

  onLoad: function () {
    this.getopenid()
    var that = this

    setTimeout(function () {
      //查找此用户记录
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
        id: that.data.openid,
      }).get({
        success: res => {
          that.setData({
            currentuser: res.data[0]
          })
          if (res.data.length > 0) {
            that.setData({
              isExist: true
            })
          }
          console.log("用户是否存在", that.data.isExist)
          //如果该用户存在
          if (that.data.isExist) {
            app.data.userid = that.data.openid
            app.data.currentuser = that.data.currentuser
            that.setData({
              isExist: false
            })

            //跳转到首页
            wx.switchTab({
              url: '../index/index'
            })
          } else {
            //跳转到登录页面
            wx.navigateTo({
              url: "/pages/login/login" 
            })
          }
        },
      })
    }, 1000);
  },
})