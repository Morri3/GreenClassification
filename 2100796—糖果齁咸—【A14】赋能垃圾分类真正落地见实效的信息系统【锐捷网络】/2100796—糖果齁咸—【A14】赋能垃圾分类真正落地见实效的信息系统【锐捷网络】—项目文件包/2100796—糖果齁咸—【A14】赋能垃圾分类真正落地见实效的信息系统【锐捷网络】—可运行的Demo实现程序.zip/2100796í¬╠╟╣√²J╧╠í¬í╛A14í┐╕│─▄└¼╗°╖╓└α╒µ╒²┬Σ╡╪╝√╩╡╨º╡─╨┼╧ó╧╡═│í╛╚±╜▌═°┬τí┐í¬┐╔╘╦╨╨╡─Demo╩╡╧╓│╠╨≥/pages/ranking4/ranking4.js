var app = getApp();

Page({
  data: {
    user:[],
    rank: [],//排名
    difficulty:'',//选择的难度
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    //获取当前用户选择的难度
    this.setData({
      difficulty:app.globalData.difficulty4
    })
    console.log(this.data.difficulty)

    //获取用户信息
    wx.cloud.init()
    const db=wx.cloud.database()
    const _ =db.command
    if(this.data.difficulty=='普通'){
      //普通难度获取数据
      db.collection('user').where({
        score4e:_.gt(0),
        time4e:_.gt(0),
      }).get({
        success:res=>{
          this.setData({
            user:res.data
          })
          console.log(this.data.user)
  
          //加载排行榜
          var newrank = [];
          //const得是原来就有的
          var lenth = this.data.user.length;
          console.log("len",lenth)
          for (var i = 0; i < lenth; i++) {
            newrank[i] = i;
          }
          console.log(newrank)
          //冒泡排序
          for (var i = 0; i < lenth - 1; i++) {
            for (var j = 0; j < lenth - 1 - i; j++) {
              var score1 = this.data.user[newrank[j]].score4e;
              console.log(score1)
              var score2 = this.data.user[newrank[j + 1]].score4e;
              console.log(score2)
              if (score1 < score2) { //相邻元素两两对比
                var temp = newrank[j + 1]; //交换元素
                newrank[j + 1] = newrank[j];
                newrank[j] = temp;
              }else if(score1 == score2){
                var time1 = this.data.user[newrank[j]].time4e;
                var time2 = this.data.user[newrank[j + 1]].time4e;
                if(time1 > time2){
                  var temp = newrank[j + 1]; //交换元素
                  newrank[j + 1] = newrank[j];
                  newrank[j] = temp;
                }
              }
            }
          }
          console.log(newrank)
          this.setData({
            rank: newrank
          })
        }
      })
    }else if(this.data.difficulty=='困难'){
      //困难难度获取数据
      db.collection('user').where({
        score4d:_.gt(0),
        time4d:_.gt(0),
      }).get({
        success:res=>{
          this.setData({
            user:res.data
          })
          console.log(this.data.user)
  
          //加载排行榜
          var newrank = [];
          //const得是原来就有的
          var lenth = this.data.user.length;
          console.log("len",lenth)
          for (var i = 0; i < lenth; i++) {
            newrank[i] = i;
          }
          console.log(newrank)
          //冒泡排序
          for (var i = 0; i < lenth - 1; i++) {
            for (var j = 0; j < lenth - 1 - i; j++) {
              var score1 = this.data.user[newrank[j]].score4d;
              console.log(score1)
              var score2 = this.data.user[newrank[j + 1]].score4d;
              console.log(score2)
              if (score1 < score2) { //相邻元素两两对比
                var temp = newrank[j + 1]; //交换元素
                newrank[j + 1] = newrank[j];
                newrank[j] = temp;
              }else if(score1 == score2){
                var time1 = this.data.user[newrank[j]].time4d;
                var time2 = this.data.user[newrank[j + 1]].time4d;
                if(time1 > time2){
                  var temp = newrank[j + 1]; //交换元素
                  newrank[j + 1] = newrank[j];
                  newrank[j] = temp;
                }
              }
            }
          }
          console.log(newrank)
          this.setData({
            rank: newrank
          })
        }
      })
    }
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})