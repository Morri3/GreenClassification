const app = getApp();
var startX, endX;
var moveFlag = true; // 判断执行滑动事件
var show = false;

Page({
  /*页面的初始数据*/
  data: {
    userid: '',
    user: '',
    gameid: 1,
    showModal: false, //是否显示游戏规则弹窗
    rules: '让小人从起点出发，收集所有规定种类的垃圾！',
    showModal_diff: false, //是否显示游戏难度弹窗
    difficulty1: '', //难度值
  },

  /*开始游戏按钮*/
  btn_startgame: function (e) {
    console.log("点击了开始分类答题");
    if (this.data.difficulty1 == '普通') {
      wx.navigateTo({
        url: '../insideGame1/insideGame1?mode=4'
      })
    } else {
      wx.navigateTo({
        url: '../insideGame1/insideGame1?mode=5'
      })
    }
  },

  /*排名*/
  ranking: function (e) {
    console.log("点击了排名111");
    if (this.data.difficulty1 == '普通') {
      wx.navigateTo({
        url: '../ranking1/ranking1?mode=普通',
      })
    } else {
      wx.navigateTo({
        url: '../ranking1/ranking1?mode=困难',
      })
    }
  },

  touchStart: function (e) {
    console.log("点击了查看游戏规则");
    startX = e.touches[0].pageX; // 获取触摸时的原点
    moveFlag = true;
  },

  touchMove: function (e) {
    endX = e.touches[0].pageX; // 获取触摸时的原点
    if (moveFlag) {
      if (endX - startX > 70) {
        console.log("向右滑动");
        this.rightclose();
        moveFlag = false;
      }
      if (startX - endX > 70) {
        console.log("向左滑动");
        this.leftshow();
        moveFlag = false;
        show = true;
      }
    }
  },

  touchEnd: function (e) {
    moveFlag = true; //恢复滑动事件
  },

  /*左划*/
  leftshow: function () {
    //跳出弹窗显示答题情况
    this.setData({
      showModal: true
    })
  },

  /*右划*/
  rightclose: function () {
    //隐藏弹窗
    this.setData({
      showModal: false
    })
  },

  //点击蒙版空白处实现关闭弹窗
  closemask: function (e) {
    console.log("关闭了游戏规则");
    //隐藏弹窗
    this.setData({
      showModal: false
    })
  },

  //点击实现显示游戏规则
  showrules: function (e) {
    //跳出弹窗显示答题情况
    this.setData({
      showModal: true
    })
  },

  /*难度*/
  difficulty: function (e) {
    console.log("点击了难度");
    //跳出弹窗显示难度
    this.setData({
      showModal_diff: true
    })
  },

  //关闭难度弹窗
  closemask_diff: function (e) {
    console.log("关闭了游戏难度弹窗");
    //隐藏弹窗
    this.setData({
      showModal_diff: false
    })
  },

  //难度选择
  diff: function (e) {
    console.log(e)
    //记录选择的难度
    this.setData({
      difficulty1: e.currentTarget.dataset.diff
    })
    console.log(this.data.difficulty1)
    app.globalData.difficulty1 = e.currentTarget.dataset.diff
    console.log(app.globalData.difficulty1)
    //选择难度后关闭弹窗
    this.setData({
      showModal_diff: false
    })
  },

  /*论坛*/
  forum: function (e) {
    console.log("点击了论坛");
    wx.navigateTo({
      url: '../fornum/fornum?gameid=' + JSON.stringify(this.data.gameid),
    })
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    var app = getApp()
    this.setData({
      userid: app.data.userid,
      difficulty1: '普通',
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      id: this.data.userid,
    }).get({
      success: res => {
        this.setData({
          user: res.data[0]
        })
        console.log(this.data.user)
      }
    })
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})