var app = getApp();

var countDown = 60 //60s倒计时

Page({
  /*页面的初始数据*/
  data: {
    second:0,//剩余时间
    useTime: 0, //使用时间

    chessboardDatas: [],
    allcells:[],
    result:[],
    currentselectedcells:[],
    isovercells:[],//最终选择结果的集合
    score:0,//最终成绩

    showModal: false, //是否显示弹窗
    toast2Hidden: true,
    selectedrow:'',
    selectedcolumn:'',
  },

  //倒计时函数
  countDown(that) {
    if(this.data.showModal==true){//如果答题完成则停止倒计时
      return
    }
    if (that.data.second == 0) {//倒计时结束了
      this.setData({
        showModal:true//倒计时结束停止倒计时
      })
      console.log(this.data.showModal)
      this.data.useTime = countDown - this.data.second

      this.setData({
        useTime: this.data.useTime,
        score: parseInt(this.data.isovercells.length/3),
      })
      //更新用户表中的第四个游戏的成绩数据
      wx.cloud.init()//初始化
      const db = wx.cloud.database()//获取db数据库
      db.collection('user').where({//如果没有查询约束条件就没有where
        id:app.data.userid
      }).get()
        .then(res=>{
          if(this.data.score>res.data[0].score4d || 
            (this.data.score==res.data[0].score4d && this.data.useTime<res.data[0].time4d)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
            db.collection('user').where({//如果没有查询约束条件就没有where
              id:app.data.userid
            }).update({//更新
              data:{
                score4d:this.data.score,
                time4d:this.data.useTime
              }
            })
          }
        })
      /*20220207-1300注释*/
      // //更新用户表中的第四个游戏的成绩数据
      // wx.cloud.init()//初始化
      // const db = wx.cloud.database()//获取db数据库
      // db.collection('user').where({//如果没有查询约束条件就没有where
      //   id:app.data.userid
      // }).update({//更新
      //   data:{
      //     score4:this.data.score,
      //     time4:60-this.data.second
      //   }
      // })
      console.log(60-this.data.second)
      return
    }
    that.setData({
      second: that.data.second - 1,
    })
    setTimeout(function () {
      that.countDown(that)
    }, 1000)
  },

  selectcell:function(options){
    console.log(this.data.chessboardDatas)
    const{chessboardDatas} = this.data;
    const{currentselectedcells} = this.data;
    const{isovercells} = this.data;
    const{result} = this.data;
    const{selectedrow} = options.currentTarget.dataset;
    const{selectedcolumn} = options.currentTarget.dataset;
    console.log(selectedrow)
    console.log(selectedcolumn)
    console.log(chessboardDatas)
    console.log(currentselectedcells)
    chessboardDatas.forEach((v,i)=>{
      if(i == selectedrow){
        v.forEach((p,j)=>{
          if(j==selectedcolumn){
            var countover = 0
            isovercells.forEach((v,i)=>{
                  if(v==p.id)
                  countover++;
                })
            console.log(countover)
            if(countover==0){
              var lenth = currentselectedcells.length
              if(lenth==0){
                currentselectedcells.push(p.id)
                this.setData({
                  currentselectedcells
                })
                this.changecolor();
              }else{
                var count = 0
                currentselectedcells.forEach((v,i)=>{
                  if(v==p.id)
                    count++;
                })
                console.log(count)
                
                if(count==0){
                  if(lenth<3){
                    currentselectedcells.push(p.id)
                    this.setData({
                      currentselectedcells
                    })
                    this.changecolor();
                  }else{
                    currentselectedcells.push(p.id)
                    this.setData({
                      currentselectedcells
                    })
                    console.log(currentselectedcells)
                    this.changecolor();
                    //判断是否对，不对的话全回来
                    var truecount=0;
                    var first = currentselectedcells[0]%5;
                    currentselectedcells.forEach((v,i)=>{
                      if(v%5!=first)
                      truecount++;
                    })
                    if(truecount==0){
                      this.setData({
                        isovercells:isovercells.concat(currentselectedcells),
                        score:this.data.score+1
                      })
                      console.log(this.data.isovercells)
                      
                      this.changeisover();

                      currentselectedcells.length = 0
                      this.setData({
                        currentselectedcells
                      })
                      this.changecolor();
                      console.log(first)
                      result.forEach((v,i)=>{
                      if((v.class+4)%5==first){
                        v.isover=true
                      }

                        
                      })
                      console.log(result)
                      this.setData({
                        result
                      })

                      // 全都找出来了，之后不用score，而是是不是所有都在预设定的数组里
                      if(this.data.score==5){
                        isovercells.length = 0
                        this.setData({
                          toast2Hidden:false,
                          showModal:true,//答题完成，显示弹窗
                          isovercells,
                          score:parseInt(this.data.isovercells.length/5),
                          useTime:countDown- this.data.second//用时
                        })
                        //更新用户表中的第四个游戏的成绩数据
                        wx.cloud.init()//初始化
                        const db = wx.cloud.database()//获取db数据库
                        
                        db.collection('user').where({//如果没有查询约束条件就没有where
                          id:app.data.userid
                        }).get()
                          .then(res=>{
                            if(this.data.score>res.data[0].score4d || 
                              (this.data.score==res.data[0].score4d && this.data.useTime<res.data[0].time4d)){//成绩比数据库高就更新数据库；成绩和数据库相同，但用时比数据库少就更新数据库
                              db.collection('user').where({//如果没有查询约束条件就没有where
                                id:app.data.userid
                              }).update({//更新
                                data:{
                                  score4d:this.data.score,
                                  time4d:this.data.useTime
                                }
                              })
                            }
                          })
                        /*20220207-1303注释*/
                        // db.collection('user').where({//如果没有查询约束条件就没有where
                        //   id:app.data.userid
                        // }).update({//更新
                        //   data:{
                        //     score4:this.data.score,
                        //     time4:this.data.useTime
                        //   }
                        // })
                      }
                    }else{
                      currentselectedcells.length=0;
                      this.setData({
                        currentselectedcells
                      })
                      console.log(currentselectedcells)
                      this.changecolor();
                    }
                    
                  }
                }
              }
            }
            
          }
        })

      }
    })
    console.log(this.data.chessboardDatas)
  },

  resetnew: function (options) {
    this.setData({
      result:[]
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    for(var i=1;i<=5;i++){
      
      db.collection('game4class').where({
        class:i
      }).get({
        success:res=>{
          res.data.sort(function(){
            return Math.random()-0.5;
          })
          console.log(res.data)
          var length = res.data.length;
          console.log(length)
          var chess = this.data.result
          chess.push(res.data[0])
          this.setData({
            result:chess
          })
          console.log(i)
          console.log(this.data.result)
          var lenth = this.data.result.length
          if(lenth==5){
            chess.sort(function(){
              return Math.random() - 0.5
            })
            this.setData({
              result:chess
            })

          }
        
        }
        
      })
    }
  },

  changecolor:function(){
    const{currentselectedcells} = this.data;
    const{chessboardDatas} = this.data;
    console.log(currentselectedcells)
    chessboardDatas.forEach((v,i)=>{
        v.forEach((p,j)=>{
          if(currentselectedcells.some(item=>{
            if(item==p.id){
              return true
            }
          })){
            p.isshow = true
          }
          else{
            p.isshow = false
          }
          
        })

    })
    this.setData({
      chessboardDatas
    })
  },

  changeisover:function(){
    const{isovercells} = this.data;
    const{chessboardDatas} = this.data;
    console.log(isovercells)
    chessboardDatas.forEach((v,i)=>{
        v.forEach((p,j)=>{
          if(isovercells.some(item=>{
            if(item==p.id){
              return true
            }

          })){
            p.isover = true
          }
          else{
            p.isover = false
          }
          
        })

    })
    this.setData({
      chessboardDatas
    })
  },

  /*重新开始一局游戏*/
  reset:function(){
    this.resetchess();
    this.resetnew();
    this.setData({
      toast2Hidden: true,
      showModal:false,
      useTime:0,
      countDown:60,
      second:60,
      score:0
    })
    this.countDown(this)
  },

  resetchess: function (options) {
    this.setData({
      allcells:[],
      chessboardDatas:[]
    })
    wx.cloud.init();
    const db = wx.cloud.database();

    for(var i=1;i<=5;i++){
      
      db.collection('game4').where({
        class:i
      }).get({
        success:res=>{
          res.data.sort(function(){
            return Math.random()-0.5;
          })
          console.log(res.data)
         
          var length = res.data.length;
          console.log(length)
          
          var chess = this.data.allcells
          console.log(chess)
          console.log(res.data.slice(0,4))
          chess = chess.concat(res.data.slice(0,4))
          console.log(chess)
          this.setData({
            allcells:chess
          })
          console.log(i)
          console.log(this.data.allcells)
          var lenth = this.data.allcells.length
          if(lenth==20){
            chess.sort(function(){
              return Math.random() - 0.5
            })
            var table = this.data.chessboardDatas;
            for(var j=0;j<lenth;j+=4){
              table.push(chess.slice(j,j+4));
              console.log(table)
            }
            console.log(table)
    
            this.setData({
              chessboardDatas:table
            })

          }
          
        }
        
      })
    }
    console.log(this.data.allcells)
  },

  //关闭弹窗
  searchclose: function (e) {
    this.setData({
      showModal: false
    })
    wx.navigateBack({
      delta: 1,
    })
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    this.resetchess();
    this.resetnew();

    //倒计时
    this.setData({
      second: countDown,
    })
    this.countDown(this)
  },
 
  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})