var util = require('../../utils/util.js');
var app = getApp(); // 获取入口文件app的应用实例
var WxSearch = require('../../wxSearch/wxSearch.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    result: [{
      keyword: '',
      score: '',
    }],
    video: false,
    margintop: 40,
    inputValue: '1',
    tempFilePath1: '', //  本地暂存路径
    fileID: '', //存储路径
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('onLoad');
    var that = this;
    //初始化的时候渲染wxSearchdata
    WxSearch.init(that, 30, ['易拉罐', '纸巾', '塑料瓶', '废电池']);
    WxSearch.initMindKeys(['易腐垃圾', '可回收物', '其他垃圾', '有害垃圾']);
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  //当点击了选项后的事件处理函数
  selectionClick: function (e) {
    var that = this;
    //此处的tempfilepath和type均为info页面所要得知的参数
    var tempFilePath;
    var type = e.target.dataset.type;
    var arr;

    //用户选择图片
    wx.chooseImage({
      success: function (res) {
        tempFilePath = res.tempFilePaths[0]
        //改变图片编码格式为base64使得符合百度API调用格式
        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0], //本地路径
          encoding: 'base64', //编码格式
          success: res => {
            //base64编码为全局变量
            app.globalData.base64 = res.data,

              wx.request({
                url: 'https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general' + '?access_token=' + app.globalData.accessToken,
                data: {
                  image: res.data,
                  baike_num: 5
                },
                method: 'POST',
                header: {
                  'content-type': 'application/x-www-form-urlencoded' // 默认值
                },
                success(res) {
                  that.setData({
                    result: res.data.result,
                  })
                  console.log(res.data.result[0].keyword);
                  for (var i = 0; i < res.data.result.length; i++) {
                    //对data赋值必须要setData，否则不会将数据赋值给视图层
                    arr = 'result[' + i + '].score'
                    //此处修改score的类型为字符串
                    that.setData({
                      [arr]: res.data.result[i].score.toFixed(2)
                    })

                  };

                  wx.request({
                    url: util.TXAPI_BASE_URL + '/txapi/lajifenlei/index', //垃圾分类接口
                    data: {
                      key: util.TXAPI_KEY,
                      word: res.data.result[0].keyword
                    },
                    success: function (res) {
                      if (res.data.code == 200) {
                        // console.log(res.data.newslist);
                        let temp_data = res.data.newslist;
                        var newSource = temp_data;
                        console.log(temp_data);
                        that.setData({
                          hideScroll: false,
                          bindSource: newSource,
                          arrayHeight: newSource.length * 71
                        })
                      } else {
                        console.error('错误码：' + res.data.code + '错误提示：' + res.data.msg + '接口文档：https://www.tianapi.com/apiview/97')
                        wx.showModal({
                          title: '垃圾分类',
                          content: res.data.msg,
                          showCancel: false,
                          success: function (res) {
                            if (res.confirm) {
                              console.log('用户点击确定')
                            }
                          }
                        })
                        that.setData({
                          hideScroll: true,
                          bindSource: []
                        })
                      }
                    }
                  })
                  // resolve();
                  wx.hideLoading();
                },
                fail(res) {
                  console.log("获取失败")
                  reject();
                },
                complete() { }
              })

            that.setData({
              tempFilePath1: tempFilePath
            })

          }
        })
      },
    })

  },


  //搜索按钮
  wxSearchFn: function (e) {
    var that = this;
    WxSearch.wxSearchAddHisKey(that);
    var prefix = WxSearch.searchmtdata(that);
    console.log(prefix.value);
    //匹配的结果
    that.setData({
      tempFilePath1: ""
    })
    var newSource = []
    if (prefix != '1') {
      wx.request({
        url: util.TXAPI_BASE_URL + '/txapi/lajifenlei/index', //垃圾分类接口
        data: {
          key: util.TXAPI_KEY,
          word: prefix.value
        },
        success: function (res) {
          if (res.data.code == 200) {
            // console.log(res.data.newslist);
            let temp_data = res.data.newslist;
            var newSource = temp_data;
            console.log(temp_data);
            that.setData({
              hideScroll: false,
              bindSource: newSource,
              arrayHeight: newSource.length * 71
            })
          } else {
            console.error('错误码：' + res.data.code + '错误提示：' + res.data.msg + '接口文档：https://www.tianapi.com/apiview/97')
            wx.showModal({
              title: '垃圾分类',
              content: res.data.msg,
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                }
              }
            })
            that.setData({
              hideScroll: true,
              bindSource: []
            })
          }
        }
      })
    }
  },
  //搜索框输入内容
  wxSearchInput: function (e) {
    var that = this
    WxSearch.wxSearchInput(e, that);
  },
  wxSerchFocus: function (e) {
    var that = this
    WxSearch.wxSearchFocus(e, that);
  },
  wxSearchBlur: function (e) {
    var that = this
    WxSearch.wxSearchBlur(e, that);
  },
  wxSearchKeyTap: function (e) {
    var that = this
    WxSearch.wxSearchKeyTap(e, that);
  },
  wxSearchDeleteKey: function (e) {
    var that = this
    WxSearch.wxSearchDeleteKey(e, that);
  },
  wxSearchDeleteAll: function (e) {
    var that = this;
    WxSearch.wxSearchDeleteAll(that);
  },
  wxSearchTap: function (e) {
    var that = this
    WxSearch.wxSearchHiddenPancel(that);
  }

})