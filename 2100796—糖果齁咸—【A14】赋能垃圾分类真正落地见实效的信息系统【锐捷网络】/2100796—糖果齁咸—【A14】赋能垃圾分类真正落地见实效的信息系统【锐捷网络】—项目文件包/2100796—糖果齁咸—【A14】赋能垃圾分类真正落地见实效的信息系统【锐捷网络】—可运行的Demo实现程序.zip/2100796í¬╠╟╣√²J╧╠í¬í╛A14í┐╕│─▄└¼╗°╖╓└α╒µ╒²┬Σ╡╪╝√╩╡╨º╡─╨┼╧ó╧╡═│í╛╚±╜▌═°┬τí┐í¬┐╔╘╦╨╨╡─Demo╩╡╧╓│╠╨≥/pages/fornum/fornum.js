// pages/catdetail/catdetail.js
Page({
  /*页面的初始数据*/
  data: {
    // gameid:'',
    gameid:4,
    userid:'',
    comments:[],
    commentid:'',
    selectedcomment:'',
    selectedcomments:'',
  },

  loadmorecomments:function(options){
    this.setData({
      selectedcomments:[]
    })

    console.log(options)
    var commentid = options.currentTarget.dataset.commentid
    console.log(commentid)

    this.setData({
      commentid:commentid
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('comment').where({ 
      gameid:this.data.gameid,
      id2:commentid

    }).get({
      success:res=>{
        this.setData({
          selectedcomments:res.data
        })
        console.log(this.data.comments)
        console.log(this.data.selectedcomments)
        var allcomments = this.data.comments;
        console.log(commentid)
        allcomments.forEach((v,i)=>{
          console.log(v._id)
          if(v._id==commentid){
            v.isselected = !v.isselected
        
          }else{
            v.isselected = false
          }
        })
        this.setData({
          comments:allcomments
        })
      }
      
    })
    

  },

  addcomment:function(options){
    console.log(options)
    var commentid = options.currentTarget.dataset.commentid
    console.log(commentid)

    wx.navigateTo({
      url: '../addcomment/addcomment?commentid='+JSON.stringify(commentid)
    })

  },

  addmycomment:function(){


    wx.navigateTo({
      url: '../addmycomment/addmycomment?commentid='+JSON.stringify(-1)+'&gameid='+JSON.stringify(this.data.gameid)
    })



  },

  /*生命周期函数--监听页面加载*/
  loadallcomments:function(){
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('comment').where({ 
      gameid:this.data.gameid,
      id2:-1
    }).get({
      success:res=>{
        // res.data.forEach((v,i)=>{
        //   v.isselected = JSON.parse(v.isselected)
        // })
        // console.log(res.data)
        this.setData({
          comments:res.data
        })
        console.log(this.data.comments)
      }
      
    })
  },

  onLoad: function (options) {
    this.setData({
      gameid:JSON.parse(options.gameid)
    })

    this.loadallcomments();
   
    
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {
    this.loadallcomments();
  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  }
})