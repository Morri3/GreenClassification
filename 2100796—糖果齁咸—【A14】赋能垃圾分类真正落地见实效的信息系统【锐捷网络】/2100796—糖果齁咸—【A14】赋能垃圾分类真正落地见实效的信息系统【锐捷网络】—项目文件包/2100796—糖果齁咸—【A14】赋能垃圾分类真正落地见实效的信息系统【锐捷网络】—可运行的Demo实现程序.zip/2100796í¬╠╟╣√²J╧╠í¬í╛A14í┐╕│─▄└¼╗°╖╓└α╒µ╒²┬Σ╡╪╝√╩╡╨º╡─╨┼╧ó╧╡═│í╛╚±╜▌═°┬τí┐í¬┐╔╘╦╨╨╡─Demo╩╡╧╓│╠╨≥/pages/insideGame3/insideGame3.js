var ans_yes = "ans_yes" //选项样式（正确给渐变绿）
var ans_mid = "option_bg"
var ans_no = "ans_no"
var flag = false //用户是否已经答题
var over = false //答题是否结束
var totalNum = 10 //题目数量
var countDown = 60 //倒计时
var right_png = "/images/right.png" //√图标
var wrong_png = "/images/wrong.png"
var start_time = "" //游戏开始时间
var end_time = ""
var level = "" //题目难度

Page({
  data: {
    ani: "", //动画
    percent: 30, //用时百分比
    second: 0, //剩余时间
    showModal: false, //显示成绩弹窗
    useTime: 0, //耗时

    class_A: "option_bg",
    class_B: "option_bg",
    class_C: "option_bg",
    class_D: "option_bg",
    src_A: "",
    src_B: "",
    src_C: "",
    src_D: "",

    cnt: 0, //当前题目
    total: 10, //题目数量
    no: 0, //答对数量
    yes: 0, //答错数量
    score: 0, //成绩
    list: [], //题目集
    wrong: [], //错题
  },

  change_class(e) {
    switch (e.ans) {
      case "A":
        this.setData({
          class_A: e.class,
          src_A: e.src,
          src_B: "",
          src_C: "",
          src_D: "",
        })
        break
      case "B":
        this.setData({
          class_B: e.class,
          src_A: "",
          src_B: e.src,
          src_C: "",
          src_D: "",
        })
        break
      case "C":
        this.setData({
          class_C: e.class,
          src_A: "",
          src_B: "",
          src_C: e.src,
          src_D: "",
        })
        break
      case "D":
        this.setData({
          class_D: e.class,
          src_A: "",
          src_B: "",
          src_C: "",
          src_D: e.src,
        })
        break
    }
  },

  choice(e) {
    if (flag) return
    flag = true
    let cnt = this.data.cnt;
    let ans = e.currentTarget.dataset.ans

    if (ans != this.data.list[cnt].ans) {
      this.data.no++

      this.change_class({
        ans: this.data.list[cnt].ans,
        class: ans_yes,
      })
      this.change_class({
        ans: ans,
        class: ans_no,
        src: wrong_png,
      })

      let tmp = this.data.list[this.data.cnt]
      tmp.class_A = this.data.class_A
      tmp.class_B = this.data.class_B
      tmp.class_C = this.data.class_C
      tmp.class_D = this.data.class_D
      tmp.src_A = this.data.src_A
      tmp.src_B = this.data.src_B
      tmp.src_C = this.data.src_C
      tmp.src_D = this.data.src_D
      this.data.wrong.push(tmp)
    } else {
      this.data.yes++
      this.change_class({
        ans: this.data.list[cnt].ans,
        class: ans_yes,
        src: right_png,
      })
    }
  },

  next() {
    let cnt = this.data.cnt
    cnt++
    if (cnt != this.data.total) {
      this.animation()
      flag = false
      this.setData({
        class_A: "option_bg",
        class_B: "option_bg",
        class_C: "option_bg",
        class_D: "option_bg",
        src_A: "",
        src_B: "",
        src_C: "",
        src_D: "",
        cnt: cnt,
      })
    } else {
      if (over == false) this.over()
      else {
        wx.showToast({
          title: '已结束',
        })
      }
    }
  },

  animation() {
    let animation = wx.createAnimation()
    animation.translate(-1000, 0).step({
      duration: 1,
    })
    animation.translate(1000, 0).step({
      duration: 1,
    })
    animation.translate(0, 0).step({
      duration: 200,
    })
    this.setData({
      ani: animation.export()
    })
  },

  getProblem() {
    wx.cloud.callFunction({
        name: "getProblem",
        data: {
          size: totalNum,
          level: level,
          collection: "game3",
        }
      })
      .then(res => {
        console.log("here", res, level);
        this.setData({
          total: res.result.list.length,
          cnt: 0,
          list: res.result.list,
        })
      })
      .catch(res => {
        console.log("no_onLoad", res);
      })
  },

  over() {
    over = true
    this.data.useTime = countDown - this.data.second
    this.setData({
      showModal: true,
      yes: this.data.yes,
      no: this.data.no,
      total: this.data.total,
      useTime: this.data.useTime,
      score: 100 * this.data.yes / this.data.total
    })
    this.record()
  },

  //记录最好成绩
  record() {
    wx.cloud.database().collection("user")
      .where({
        _openid: getApp().data.userid
      })
      .get()
      .then(res => {
        if (level == '普通') {
          if (res.data[0].score3e < this.data.score || res.data[0].score3e == this.data.score && res.data[0].time3e > this.data.useTime) {
            wx.cloud.database().collection("user")
              .where({
                _openid: getApp().data.userid
              })
              .update({
                data: {
                  score3e: this.data.score,
                  time3e: this.data.useTime,
                }
              })
          }
        } else {
          if (res.data[0].score3d < this.data.score || res.data[0].score3d == this.data.score && res.data[0].time3d > this.data.useTime) {
            wx.cloud.database().collection("user")
              .where({
                _openid: getApp().data.userid
              })
              .update({
                data: {
                  score3d: this.data.score,
                  time3d: this.data.useTime,
                }
              })
          }
        }
      })
  },

  countDown(that) {
    if (over) return
    if (that.data.second == 0) {
      over = true
      this.over()
      return
    }
    that.setData({
      second: that.data.second - 1,
    })
    setTimeout(function () {
      that.countDown(that)
    }, 1000)
  },

  //关闭弹窗
  searchclose: function (e) {
    wx.navigateBack({
      delta: 1,
    })
  },

  //查看错题
  searchwrong: function (e) {
    console.log("inde3",this.data.wrong);
    let str = JSON.stringify({
      wrong: this.data.wrong
    })
    wx.redirectTo({
      url: '../wrongquestion3/wrongquestion3?item=' + str,
    })
  },

  onLoad: function (e) {
    level = e.level
    flag = false
    over = false
    start_time = new Date().getTime()
    this.getProblem()
    // this.setData({
    //   second: 0,
    // })
    // this.useTime(this)
    this.setData({
      second: countDown,
      showModal: false,
    })
    this.countDown(this)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})