const app = getApp();
var WxSearch = require('../../wxSearch/wxSearch.js')

Page({
  /*页面的初始数据*/
  data: {
    city: '',
    newsid: '',
    rubbishtabindex: 0,
    rubbishes: '',
    rubbishclass: '',
    cityPickerValue: [0, 0],
    cityPickerIsShow: false,

    userid: '',
    user: '',
    precheckTimes: 0,
    //news
    news: '',
    news1: '',
    news2: '',
    newstabid: 0,

    test: [1, 2, 3, 4],
    index: 0,
    rubbishtabs: [{ id: 0, value: "易腐垃圾", isActive: true },
    { id: 1, value: "可回收物", isActive: false },
    { id: 2, value: "其他垃圾", isActive: false },
    { id: 3, value: "有害垃圾", isActive: false }],

    rubbishtabsnormal: [{ id: 0, value: "易腐垃圾", isActive: true },
    { id: 1, value: "可回收物", isActive: false },
    { id: 2, value: "其他垃圾", isActive: false },
    { id: 3, value: "有害垃圾", isActive: false }],

    tabs: [{ id: 0, value: "最新推荐", isActive: true },
    { id: 1, value: "小知识", isActive: false },
    { id: 2, value: "环保资讯", isActive: false }],//是否选中

    rubbishtabsShanghai: [{ id: 0, value: "湿垃圾", isActive: true },
    { id: 1, value: "可回收物", isActive: false },
    { id: 2, value: "干垃圾", isActive: false },
    { id: 3, value: "有害垃圾", isActive: false }],

    rubbishtabsShanghai1: [{ id: 0, value: "湿垃圾", isActive: true },
    { id: 1, value: "可回收物", isActive: false },
    { id: 2, value: "干垃圾", isActive: false },
    { id: 3, value: "有害垃圾", isActive: false }],
  },

  btnnews: function (e) {
    const { newsid } = e.currentTarget.dataset;

    this.setData({
      newsid: newsid
    })

    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      id: this.data.userid
    }).get({
      success: res => {

        this.setData({
          precheckTimes: res.data[0].checknewsTime
        })

        db.collection('user').where({
          id: this.data.userid
        }).update({
          data: ({
            checknewsTime: this.data.precheckTimes + 1
          })
        })

      }

    })

    wx.navigateTo({
      url: "/pages/newsdetail/newsdetail?newsid=" + JSON.stringify(newsid),
    })
  },
  handleItemTap: function (e) {
    const { tabid } = e.currentTarget.dataset;
    const { tabs } = this.data;
    tabs.forEach((v, i) => v.id === tabid ? v.isActive = true : v.isActive = false);

    this.setData({
      newstabid: tabid,
      tabs
    })



    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('news_url').where({
      newsclass: this.data.newstabid,
    }).get({
      success: res => {
        this.setData({
          news: res.data
        })



        var news1 = [];
        var news2 = [];
        res.data.forEach((v, i) => {
          if (i % 2 == 0) {
            news1.push(v);
          } else {
            news2.push(v);
          }
        })

        this.setData({
          news1: news1,
          news2: news2
        })
      }
    })
  },

  handleRubbishItemTap: function (e) {

    wx.cloud.init();
    const db = wx.cloud.database();

    if (this.data.city == "上海市市辖区") {
      let { rubbishtabindex } = e.currentTarget.dataset;
      let { rubbishtabsShanghai } = this.data;
      rubbishtabsShanghai.forEach((v, i) => i == rubbishtabindex ? v.isActive = true : v.isActive = false);
      this.setData({
        rubbishtabs: rubbishtabsShanghai,
        rubbishtabindex
      })
      db.collection('classShanghai').where({
        id: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })

        }
      })
      db.collection('rubbishes').where({
        classid: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    } else {
      let { rubbishtabindex } = e.currentTarget.dataset;
      let { rubbishtabsnormal } = this.data;
      rubbishtabsnormal.forEach((v, i) => i == rubbishtabindex ? v.isActive = true : v.isActive = false);
      this.setData({
        rubbishtabs: rubbishtabsnormal,
        rubbishtabindex
      })
      db.collection('class').where({
        id: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })
        }
      })
      db.collection('rubbishes').where({
        classid: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    }
  },



  clickList: function (e) {

    let num = e.target.id

    let content = this.data.message[num].content
    this.setData({
      num: num,
      content: content
    })

  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    var app = getApp()
    this.setData({
      userid: app.data.userid,
    })
    //云数据
    wx.cloud.init();
    const db = wx.cloud.database();

    db.collection('news_url').where({
      newsclass: this.data.newstabid,
    }).get({
      success: res => {
        this.setData({
          news: res.data
        })
        var news1 = [];
        var news2 = [];
        res.data.forEach((v, i) => {
          if (i % 2 == 0) {
            news1.push(v);
          } else {
            news2.push(v);
          }
        })
        this.setData({
          news1: news1,
          news2: news2
        })


      }
    })


    if (this.data.city == "上海市市辖区") {
      let { rubbishtabindex } = this.data;
      let { rubbishtabsShanghai } = this.data;
      rubbishtabsShanghai.forEach((v, i) => i == rubbishtabindex ? v.isActive = true : v.isActive = false);
      this.setData({
        rubbishtabs: rubbishtabsShanghai,
        rubbishtabindex
      })
      db.collection('classShanghai').where({
        id: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })
        }
      })
      db.collection('rubbishes').where({
        classid: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    } else {
      let { rubbishtabindex } = this.data;
      let { rubbishtabsnormal } = this.data;
      rubbishtabsnormal.forEach((v, i) => i == rubbishtabindex ? v.isActive = true : v.isActive = false);
      this.setData({
        rubbishtabs: rubbishtabsnormal,
        rubbishtabindex
      })
      db.collection('class').where({
        id: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })
        }
      })
      db.collection('rubbishes').where({
        classid: this.data.rubbishtabindex,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    }

    wx.hideTabBar();
    app.editTabbar();

    var that = this;
    //初始化的时候渲染wxSearchdata
    WxSearch.init(that, 30, ['易拉罐', '使用过的纸巾', '饮料瓶', '废电池']);
    WxSearch.initMindKeys(['易腐垃圾', '可回收物', '其他垃圾', '有害垃圾']);
  },

  /*生命周期函数--监听页面初次渲染完成*/
  onReady: function () {

  },

  /*生命周期函数--监听页面显示*/
  onShow: function () {

  },

  /*生命周期函数--监听页面隐藏*/
  onHide: function () {

  },

  /*生命周期函数--监听页面卸载*/
  onUnload: function () {

  },

  /*页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {

  },

  /*页面上拉触底事件的处理函数*/
  onReachBottom: function () {

  },

  /*用户点击右上角分享*/
  onShareAppMessage: function () {

  },

  /*城市选择确认*/
  cityPickerOnSureClick: function (e) {

    this.setData({
      city: e.detail.valueName[0] + e.detail.valueName[1],
      cityPickerValue: e.detail.valueCode,
      cityPickerIsShow: false,
    });
    wx.cloud.init();
    const db = wx.cloud.database();
    if (this.data.city == "上海市市辖区") {
      let { rubbishtabsShanghai } = this.data;

      rubbishtabsShanghai.forEach((element,index) => {
        if(index===0){
          element.isActive=true;
        }else{
          element.isActive=false;
        }
      });;

      
      this.setData({
        rubbishtabs: rubbishtabsShanghai,
      })
      db.collection('classShanghai').where({
        id: 0,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })
        }
      })
      db.collection('rubbishes').where({
        classid: 0,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    } else {
      let { rubbishtabsnormal } = this.data;

      rubbishtabsnormal.forEach((element,index) => {
        if(index===0){
          element.isActive=true;
        }else{
          element.isActive=false;
        }
      });;
      this.setData({
        rubbishtabs: rubbishtabsnormal,
      })
      db.collection('class').where({
        id: 0,
      }).get({
        success: res => {
          this.setData({
            rubbishclass: res.data[0],
          })
        }
      })
      db.collection('rubbishes').where({
        classid: 0,
      }).get({
        success: res => {
          this.setData({
            rubbishes: res.data
          })
        }
      })
    }

  },

  /*城市选择取消*/
  cityPickerOnCancelClick: function (event) {
    console.log('cityPickerOnCancelClick');
    console.log(event);
    this.setData({
      cityPickerIsShow: false,
    });
  },

  showCityPicker() {
    // this.data.cityPicker.show()
    this.setData({
      cityPickerIsShow: true,
    });
  },

  


 
})
